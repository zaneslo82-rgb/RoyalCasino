package ru.yourname.royalcasino.games;

import java.util.HashSet;

public class TreasureSession {
    private final double initialBet;
    private final HashSet<Integer> bombSlots;
    private int diamondsFound = 0;
    private boolean isFinished = false;

    public TreasureSession(double bet, HashSet<Integer> bombs) {
        this.initialBet = bet;
        this.bombSlots = bombs;
    }

    public double getBet() {
        return initialBet;
    }

    public HashSet<Integer> getBombSlots() {
        return bombSlots;
    }

    public int getDiamondsFound() {
        return diamondsFound;
    }

    public void addDiamond() {
        diamondsFound++;
    }

    // Логика множителя: каждый алмаз добавляет 20% к выигрышу
    public double getCurrentMultiplier() {
        return 1.10 + (diamondsFound * 0.25); 
        // Пример:
        // 0 алмазов = 1.10x (но вывести нельзя)
        // 1 алмаз = 1.35x
        // 2 алмаза = 1.60x
    }

    public boolean isFinished() {
        return isFinished;
    }

    public void setFinished(boolean finished) {
        isFinished = finished;
    }
}