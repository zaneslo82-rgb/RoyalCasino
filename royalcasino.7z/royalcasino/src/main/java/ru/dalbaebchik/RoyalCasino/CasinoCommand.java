package ru.dalbaebchik.royalcasino;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import ru.dalbaebchik.royalcasino.games.BlackjackGame;
import ru.dalbaebchik.royalcasino.games.DiceGame;
import ru.dalbaebchik.royalcasino.games.TreasureGame;
import ru.dalbaebchik.royalcasino.games.WheelGame;

public class CasinoCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;

        if (args.length < 2) {
            player.sendMessage("§eCasino by t.me/eelicedcer");
            player.sendMessage("§6/casino treasure <bet>");
            player.sendMessage("§6/casino wheel <bet>");
            player.sendMessage("§6/casino dice <bet>");
            player.sendMessage("§6/casino blackjack <bet>");
            return true;
        }

        double bet;
        try {
            bet = Double.parseDouble(args[1]);
        } catch (NumberFormatException e) {
            player.sendMessage("§cInvalid number");
            return true;
        }

        if (bet <= 0) {
            player.sendMessage("§cBet must be > 0");
            return true;
        }

        if (RoyalCasino.getEconomy().getBalance(player) < bet) {
            player.sendMessage("§cNot enough money!");
            return true;
        }

        String mode = args[0].toLowerCase();
        
        if (mode.equals("treasure")) new TreasureGame().start(player, bet);
        else if (mode.equals("wheel")) new WheelGame().start(player, bet);
        else if (mode.equals("dice")) new DiceGame().start(player, bet);
        else if (mode.equals("blackjack")) new BlackjackGame().start(player, bet);
        else player.sendMessage("§cUnknown game");

        return true;
    }
}