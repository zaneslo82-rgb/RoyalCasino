package ru.dalbaebchik.royalcasino.games;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.dalbaebchik.royalcasino.RoyalCasino;

import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

public class DiceGame {

    public static HashMap<UUID, Double> bets = new HashMap<>();

    public void start(Player player, double bet) {
        RoyalCasino.getEconomy().withdrawPlayer(player, bet);
        bets.put(player.getUniqueId(), bet);

        Inventory inv = Bukkit.createInventory(null, 27, "§8Dice Game");

        setItem(inv, 10, Material.BLUE_WOOL, "§9EVEN (x2)", "2, 4, 6");
        setItem(inv, 12, Material.RED_WOOL, "§cODD (x2)", "1, 3, 5");
        setItem(inv, 14, Material.GOLD_BLOCK, "§6LUCKY 6 (x5)", "Only 6");
        setItem(inv, 16, Material.COAL_BLOCK, "§8LOW (1-3) (x2)", "1, 2, 3");

        player.openInventory(inv);
    }

    private void setItem(Inventory inv, int slot, Material mat, String name, String lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(java.util.Collections.singletonList(lore));
        item.setItemMeta(meta);
        inv.setItem(slot, item);
    }

    public static void handleClick(Player p, int slot, Inventory inv) {
        if (!bets.containsKey(p.getUniqueId())) return;
        double bet = bets.get(p.getUniqueId());
        
        int roll = new Random().nextInt(6) + 1; 
        double win = 0;
        boolean played = false;

        if (slot == 10) { 
            played = true;
            if (roll % 2 == 0) win = bet * 2;
        } else if (slot == 12) {
            played = true;
            if (roll % 2 != 0) win = bet * 2;
        } else if (slot == 14) {
            played = true;
            if (roll == 6) win = bet * 5;
        } else if (slot == 16) {
            played = true;
            if (roll <= 3) win = bet * 2;
        }

        if (played) {
            bets.remove(p.getUniqueId());
            p.sendMessage("§eRolled: §l" + roll);
            
            ItemStack res = new ItemStack(Material.PAPER);
            ItemMeta meta = res.getItemMeta();
            meta.setDisplayName("§eResult: " + roll);
            res.setItemMeta(meta);
            inv.setItem(4, res);

            if (win > 0) {
                RoyalCasino.getEconomy().depositPlayer(p, win);
                p.sendMessage("§aWon " + win);
                p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
            } else {
                p.sendMessage("§cLost.");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
            }
            p.closeInventory();
        }
    }
}