package ru.dalbaebchik.royalcasino.games;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.scheduler.BukkitRunnable;
import ru.dalbaebchik.royalcasino.RoyalCasino;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

public class BlackjackGame {

    public static HashMap<UUID, BJSession> sessions = new HashMap<>();

    public void start(Player player, double bet) {
        if (RoyalCasino.getEconomy().getBalance(player) < bet) {
            player.sendMessage("§cNot enough money!");
            return;
        }
        RoyalCasino.getEconomy().withdrawPlayer(player, bet);

        BJSession session = new BJSession(bet);
        sessions.put(player.getUniqueId(), session);
        
        Inventory inv = Bukkit.createInventory(null, 54, "§0Blackjack Table");
        openGui(player, inv, session);
        player.openInventory(inv);
    }

    public static void handleClick(Player p, int slot, Inventory inv) {
        BJSession session = sessions.get(p.getUniqueId());
        if (session == null || session.isBusy) return;

        if (slot == 48) { 
            p.playSound(p.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1.5f);
            session.playerHand.add(session.drawCard());
            if (session.calc(session.playerHand) > 21) {
                updateGui(inv, session, true);
                endGame(p, session, false);
            } else {
                updateGui(inv, session, false);
            }
        } 
        else if (slot == 50) { 
            startDealerTurn(p, inv, session);
        }
        else if (slot == 49) {
            if (RoyalCasino.getEconomy().getBalance(p) < session.bet) {
                p.sendMessage("§cNot enough money to double!");
                p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
                return;
            }
            RoyalCasino.getEconomy().withdrawPlayer(p, session.bet);
            session.bet *= 2;
            p.sendMessage("§6Double Down! Bet: " + session.bet);
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 2f);
            
            session.playerHand.add(session.drawCard());
            if (session.calc(session.playerHand) > 21) {
                updateGui(inv, session, true);
                endGame(p, session, false);
            } else {
                startDealerTurn(p, inv, session);
            }
        }
    }

    private static void startDealerTurn(Player p, Inventory inv, BJSession s) {
        s.isBusy = true;
        updateGui(inv, s, true); 
        p.playSound(p.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 1f, 1f);

        new BukkitRunnable() {
            @Override
            public void run() {
                if (!p.isOnline() || !sessions.containsKey(p.getUniqueId())) {
                    this.cancel();
                    return;
                }

                int dVal = s.calc(s.dealerHand);
                if (dVal < 17) {
                    s.dealerHand.add(s.drawCard());
                    p.playSound(p.getLocation(), Sound.ITEM_BOOK_PAGE_TURN, 1f, 1f);
                    updateGui(inv, s, true);
                } else {
                    this.cancel();
                    finishGame(p, s);
                }
            }
        }.runTaskTimer(RoyalCasino.getInstance(), 15L, 15L);
    }

    private static void finishGame(Player p, BJSession s) {
        int pVal = s.calc(s.playerHand);
        int dVal = s.calc(s.dealerHand);

        if (dVal > 21 || pVal > dVal) {
            endGame(p, s, true);
        } else if (dVal == pVal) {
            RoyalCasino.getEconomy().depositPlayer(p, s.bet);
            p.sendMessage("§ePush (Draw). Money back.");
            p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 1f, 2f);
            s.isBusy = false;
            p.closeInventory();
            sessions.remove(p.getUniqueId());
        } else {
            endGame(p, s, false);
        }
    }

    private static void openGui(Player p, Inventory inv, BJSession s) {
        ItemStack bg = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta bgm = bg.getItemMeta();
        bgm.setDisplayName(" ");
        bg.setItemMeta(bgm);
        for(int i=0; i<54; i++) inv.setItem(i, bg);

        updateGui(inv, s, false);
    }

    private static void updateGui(Inventory inv, BJSession s, boolean revealDealer) {
        ItemStack separator = new ItemStack(Material.WHITE_STAINED_GLASS_PANE);
        ItemMeta sem = separator.getItemMeta();
        sem.setDisplayName("§7-----------------");
        separator.setItemMeta(sem);
        for (int i = 27; i < 36; i++) inv.setItem(i, separator);

        for (int i = 0; i < 9; i++) {
            inv.setItem(i+10, new ItemStack(Material.AIR));
            inv.setItem(i+37, new ItemStack(Material.AIR));
        }

        if (revealDealer) {
            for (int i = 0; i < s.dealerHand.size(); i++) {
                inv.setItem(i + 10, makeCard(s.dealerHand.get(i)));
            }
            inv.setItem(4, makeHead("MHF_Villager", "§c§lDEALER: " + s.calc(s.dealerHand)));
        } else {
            inv.setItem(10, makeCard(s.dealerHand.get(0)));
            ItemStack hidden = new ItemStack(Material.RED_STAINED_GLASS_PANE);
            ItemMeta hm = hidden.getItemMeta();
            hm.setDisplayName("§c§lHIDDEN CARD");
            hidden.setItemMeta(hm);
            inv.setItem(11, hidden);
            inv.setItem(4, makeHead("MHF_Villager", "§c§lDEALER: ?"));
        }

        for (int i = 0; i < s.playerHand.size(); i++) {
            inv.setItem(i + 37, makeCard(s.playerHand.get(i)));
        }
        inv.setItem(40, makeHead(null, "§a§lYOU: " + s.calc(s.playerHand)));

        if (!s.isBusy) {
            ItemStack hit = new ItemStack(Material.LIME_CONCRETE);
            ItemMeta hm = hit.getItemMeta();
            hm.setDisplayName("§a§lHIT");
            hit.setItemMeta(hm);
            inv.setItem(48, hit);

            ItemStack stand = new ItemStack(Material.RED_CONCRETE);
            ItemMeta sm = stand.getItemMeta();
            sm.setDisplayName("§c§lSTAND");
            stand.setItemMeta(sm);
            inv.setItem(50, stand);
            
            if (s.playerHand.size() == 2) {
                ItemStack dbl = new ItemStack(Material.GOLD_BLOCK);
                ItemMeta dm = dbl.getItemMeta();
                dm.setDisplayName("§6§lDOUBLE x2");
                dbl.setItemMeta(dm);
                inv.setItem(49, dbl);
            } else {
                inv.setItem(49, new ItemStack(Material.AIR));
            }
        } else {
            inv.setItem(48, new ItemStack(Material.AIR));
            inv.setItem(49, new ItemStack(Material.AIR));
            inv.setItem(50, new ItemStack(Material.AIR));
        }
    }

    private static ItemStack makeCard(Card card) {
        Material mat = Material.PAPER;
        String color = "§f";
        if (card.suit == 0 || card.suit == 1) color = "§c"; 
        
        ItemStack is = new ItemStack(mat);
        ItemMeta meta = is.getItemMeta();
        meta.setDisplayName(color + card.toString());
        is.setItemMeta(meta);
        return is;
    }

    private static ItemStack makeHead(String owner, String name) {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = head.getItemMeta();
        meta.setDisplayName(name);
        head.setItemMeta(meta);
        return head;
    }

    private static void endGame(Player p, BJSession s, boolean win) {
        s.isBusy = false;
        if (win) {
            double amount = s.bet * 2;
            if (s.calc(s.playerHand) == 21 && s.playerHand.size() == 2) {
                amount = s.bet * 2.5;
                p.sendMessage("§6§lBLACKJACK! x2.5");
            }
            RoyalCasino.getEconomy().depositPlayer(p, amount);
            p.sendMessage("§aYou won " + amount);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        } else {
            p.sendMessage("§cYou lost " + s.bet);
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_BREAK_BLOCK, 0.5f, 0.5f);
        }
        p.closeInventory();
        sessions.remove(p.getUniqueId());
    }
    
    public static void handleClose(Player p) {
        sessions.remove(p.getUniqueId());
    }

    public static class Card {
        int value;
        int suit; 
        String name;

        public Card(int v, int s) {
            this.value = v;
            this.suit = s;
            if (v == 1) name = "Ace";
            else if (v == 11) name = "Jack";
            else if (v == 12) name = "Queen";
            else if (v == 13) name = "King";
            else name = String.valueOf(v);
        }
        
        @Override
        public String toString() {
            String sName = switch (suit) {
                case 0 -> "♥";
                case 1 -> "♦";
                case 2 -> "♣";
                case 3 -> "♠";
                default -> "";
            };
            return name + " " + sName;
        }

        public int getGameValue() {
            if (value >= 10) return 10;
            return value;
        }
    }

    public static class BJSession {
        double bet;
        ArrayList<Card> deck = new ArrayList<>();
        ArrayList<Card> playerHand = new ArrayList<>();
        ArrayList<Card> dealerHand = new ArrayList<>();
        boolean isBusy = false;

        public BJSession(double bet) {
            this.bet = bet;
            for (int s = 0; s < 4; s++) {
                for (int v = 1; v <= 13; v++) {
                    deck.add(new Card(v, s));
                }
            }
            Collections.shuffle(deck);
            playerHand.add(drawCard());
            dealerHand.add(drawCard());
            playerHand.add(drawCard());
            dealerHand.add(drawCard());
        }

        Card drawCard() {
            if (deck.isEmpty()) return new Card(1, 0);
            return deck.remove(0);
        }

        int calc(ArrayList<Card> hand) {
            int sum = 0;
            int aces = 0;
            for (Card c : hand) {
                int v = c.getGameValue();
                if (c.value == 1) aces++;
                else sum += v;
            }
            for (int i = 0; i < aces; i++) {
                if (sum + 11 <= 21) sum += 11;
                else sum += 1;
            }
            return sum;
        }
    }
}