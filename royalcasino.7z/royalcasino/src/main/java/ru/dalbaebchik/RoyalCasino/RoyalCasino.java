package ru.dalbaebchik.royalcasino;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class RoyalCasino extends JavaPlugin {

    private static Economy econ = null;
    private static RoyalCasino instance;

    @Override
    public void onEnable() {
        instance = this;
        if (!setupEconomy()) {
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getCommand("casino").setExecutor(new CasinoCommand());
        getServer().getPluginManager().registerEvents(new CasinoListener(), this);
        getLogger().info("Enabled. Creator: t.me/eelicedcer");
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            return false;
        }
        econ = rsp.getProvider();
        return econ != null;
    }

    public static Economy getEconomy() {
        return econ;
    }

    public static RoyalCasino getInstance() {
        return instance;
    }
}