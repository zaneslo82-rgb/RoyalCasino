package ru.dalbaebchik.royalcasino;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import ru.dalbaebchik.royalcasino.games.BlackjackGame;
import ru.dalbaebchik.royalcasino.games.DiceGame;
import ru.dalbaebchik.royalcasino.games.TreasureGame;
import ru.dalbaebchik.royalcasino.games.WheelGame;

public class CasinoListener implements Listener {

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        String title = e.getView().getTitle();
        Player p = (Player) e.getWhoClicked();

        if (title.contains("Treasure")) {
            e.setCancelled(true);
            TreasureGame.handleClick(p, e.getRawSlot(), e.getInventory(), e.getCurrentItem());
        } 
        else if (title.contains("Wheel")) {
            e.setCancelled(true);
            WheelGame.handleClick(p, e.getRawSlot(), e.getInventory());
        }
        else if (title.contains("Dice")) {
            e.setCancelled(true);
            DiceGame.handleClick(p, e.getRawSlot(), e.getInventory());
        }
        else if (title.contains("Blackjack")) {
            e.setCancelled(true);
            BlackjackGame.handleClick(p, e.getRawSlot(), e.getInventory());
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        String title = e.getView().getTitle();
        Player p = (Player) e.getPlayer();

        if (title.contains("Treasure")) TreasureGame.handleClose(p);
        if (title.contains("Blackjack")) BlackjackGame.handleClose(p);
    }
}