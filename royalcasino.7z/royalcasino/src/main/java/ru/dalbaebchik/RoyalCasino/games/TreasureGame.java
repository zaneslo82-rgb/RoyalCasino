package ru.dalbaebchik.royalcasino.games;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import ru.dalbaebchik.royalcasino.RoyalCasino;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.UUID;

public class TreasureGame {

    public static HashMap<UUID, TreasureSession> sessions = new HashMap<>();
    private final Random random = new Random();

    public void start(Player player, double bet) {
        RoyalCasino.getEconomy().withdrawPlayer(player, bet);
        Inventory gui = Bukkit.createInventory(null, 54, "§8Treasure Hunt");
        
        ItemStack sand = new ItemStack(Material.SAND);
        ItemMeta meta = sand.getItemMeta();
        meta.setDisplayName("§e???");
        sand.setItemMeta(meta);
        for (int i = 0; i < 45; i++) {
            gui.setItem(i, sand);
        }
        
        ItemStack stop = new ItemStack(Material.RED_STAINED_GLASS_PANE);
        ItemMeta sm = stop.getItemMeta();
        sm.setDisplayName("§cDIG!");
        stop.setItemMeta(sm);
        gui.setItem(49, stop);

        HashSet<Integer> bombs = new HashSet<>();
        while (bombs.size() < 5) {
            bombs.add(random.nextInt(45));
        }

        sessions.put(player.getUniqueId(), new TreasureSession(bet, bombs));
        player.openInventory(gui);
    }

    public static void handleClick(Player p, int slot, Inventory inv, ItemStack item) {
        TreasureSession session = sessions.get(p.getUniqueId());
        if (session == null || session.isFinished) return;

        if (slot < 45 && item != null && item.getType() == Material.SAND) {
            if (session.bombSlots.contains(slot)) {
                inv.setItem(slot, new ItemStack(Material.TNT));
                p.playSound(p.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 1f, 1f);
                p.sendMessage("§cBOOM!");
                session.isFinished = true;
                sessions.remove(p.getUniqueId());
            } else {
                session.diamondsFound++;
                inv.setItem(slot, new ItemStack(Material.DIAMOND));
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1f, 2f);
                
                ItemStack cashout = new ItemStack(Material.EMERALD);
                ItemMeta meta = cashout.getItemMeta();
                double win = session.bet * (1.0 + (session.diamondsFound * 0.3));
                meta.setDisplayName("§aTake §e" + String.format("%.0f", win));
                cashout.setItemMeta(meta);
                inv.setItem(49, cashout);
            }
        } else if (slot == 49 && session.diamondsFound > 0) {
            double win = session.bet * (1.0 + (session.diamondsFound * 0.3));
            RoyalCasino.getEconomy().depositPlayer(p, win);
            p.sendMessage("§aWin: " + String.format("%.0f", win));
            session.isFinished = true;
            p.closeInventory();
            sessions.remove(p.getUniqueId());
        }
    }

    public static void handleClose(Player p) {
        sessions.remove(p.getUniqueId());
    }

    public static class TreasureSession {
        double bet;
        HashSet<Integer> bombSlots;
        int diamondsFound = 0;
        boolean isFinished = false;

        public TreasureSession(double bet, HashSet<Integer> bombs) {
            this.bet = bet;
            this.bombSlots = bombs;
        }
    }
}