package ru.dalbaebchik.royalcasino.games;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import ru.dalbaebchik.royalcasino.RoyalCasino;

import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

public class WheelGame {

    public static HashMap<UUID, Double> bets = new HashMap<>();
    private final Random random = new Random();
    private final Material[] prizes = {
            Material.COAL, Material.IRON_INGOT, Material.GOLD_INGOT, 
            Material.DIAMOND, Material.EMERALD, Material.NETHERITE_INGOT
    };
    private final double[] multipliers = {0.0, 0.5, 1.2, 2.0, 3.5, 10.0};

    public void start(Player player, double bet) {
        RoyalCasino.getEconomy().withdrawPlayer(player, bet);
        bets.put(player.getUniqueId(), bet);

        Inventory inv = Bukkit.createInventory(null, 27, "§8Wheel of Fortune");
        
        ItemStack btn = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
        ItemMeta meta = btn.getItemMeta();
        meta.setDisplayName("§aCLICK TO SPIN");
        btn.setItemMeta(meta);
        inv.setItem(13, btn);

        player.openInventory(inv);
    }

    public static void handleClick(Player p, int slot, Inventory inv) {
        if (slot == 13 && bets.containsKey(p.getUniqueId())) {
            double bet = bets.get(p.getUniqueId());
            bets.remove(p.getUniqueId());
            inv.setItem(13, new ItemStack(Material.YELLOW_STAINED_GLASS_PANE));
            new WheelGame().spin(p, inv, bet);
        }
    }

    private void spin(Player p, Inventory inv, double bet) {
        new BukkitRunnable() {
            int ticks = 0;
            int maxTicks = 30 + random.nextInt(20);
            int lastIndex = 0;

            @Override
            public void run() {
                if (ticks >= maxTicks) {
                    finish(p, lastIndex, bet);
                    cancel();
                    return;
                }
                
                lastIndex = random.nextInt(prizes.length);
                ItemStack item = new ItemStack(prizes[lastIndex]);
                ItemMeta meta = item.getItemMeta();
                meta.setDisplayName("§6x" + multipliers[lastIndex]);
                item.setItemMeta(meta);
                inv.setItem(13, item);
                
                p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_HAT, 1f, 1f);
                ticks++;
            }
        }.runTaskTimer(RoyalCasino.getInstance(), 0L, 2L);
    }

    private void finish(Player p, int index, double bet) {
        double mult = multipliers[index];
        double win = bet * mult;
        
        if (win > 0) {
            RoyalCasino.getEconomy().depositPlayer(p, win);
            p.sendMessage("§aWin: " + String.format("%.0f", win));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        } else {
            p.sendMessage("§cLost " + bet);
            p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
        }
    }
}